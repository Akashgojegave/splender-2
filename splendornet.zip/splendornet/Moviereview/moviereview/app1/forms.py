from django import forms

from .models import Movie_model


class Movie_form(forms.ModelForm):
    class Meta:
        model=Movie_model
        fields="__all__"

        labels={
            "id":"Movie ID",
            "movieTitle":"Movie Title",
            "reviewContent":"Review Content",
            "rating":"Rating",
            "createdAt":"Created Date",
            "reviewer_email_id":"Reviewer Email id",
            "status":"Status",
            "genres":"Movie Genres"


        }

        widgets={
           

            "id": forms.NumberInput(attrs={"class":"form-control"}),
            "movieTitle": forms.TextInput(attrs={"class":"form-control"}),
            "reviewContent": forms.TextInput(attrs={"class":"form-control"}),
            "rating": forms.NumberInput(attrs={"class":"form-control"}),
            "createdAt": forms.TextInput(attrs={"class":"form-control"}),
            "reviewer_email_id": forms.EmailInput(attrs={"class":"form-control"}),
            "status": forms.TextInput(attrs={"class":"form-control"}),
            "genres": forms.TextInput(attrs={"class":"form-control"}),
        }

