from django.shortcuts import render

# Create your views here.

from django.shortcuts import render, redirect

from .forms import Movie_form
from .models import Movie_model


# Create your views here.


def movie_view(request):
    form=Movie_form()
    if request.method=="POST":
        form=Movie_form(request.POST)
        if form.is_valid():
            form.save()
            return redirect("read_url")

    context={
        "form":form
    }
    return render(request,"app1/create.html",context)



def movie_read(request):
    obj=Movie_model.objects.all()
    context={
        "obj":obj
    }
    return render(request,"app1/read.html",context)

def movie_update(request , pk):
    obj=Movie_model.objects.get(id=pk)
    form=Movie_form(instance=obj)
    if request.method == "POST":
        form=Movie_form(request.POST,instance=obj)
        if form.is_valid():
            form.save()
            return redirect("read_url")
    context={
        "form":form
    }
    return render(request, "app1/create.html",context)

def movie_delete(request,pk):
    obj = Movie_model.objects.get(id=pk)
    context={
        "obj":obj}
    obj.delete()
    return redirect("read_url")




# def movie_search(request , pk):
#     obj=Movie_model.objects.get(movieTitle=pk)
#     form=Movie_form(instance=obj)
#     context={
#         "form":form
#     }
#     return render(request, "app1/create.html",context)
